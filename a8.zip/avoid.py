from __future__ import division
import pygame
import math
import random

def generate_asteroid(width, height): #define a function to generate a new asteroid
	zone = random.choice(["top_left","top_middle","top_right"]) #areas that the new asteroid will come from
	if zone == "top_left":
		x = random.randint(0,260) #start at top left between 0-260 on x-axis
		y = 0 #start at 0 on y-axis
		angle = random.randint(200,300) #angles between 200-300 deg
		return Asteroid((x,y),angle)
		
	elif zone == "top_middle": 
		x = random.randint(260,526) #start at top middle between 260-526 on x-axis
		y = 0 #start at 0 on y-axis
		angle = random.randint(190,310) #angles between 190-310 deg
		return Asteroid((x,y),angle)
		
	else:
		x = random.randint(526,800) #start at top right between 526-800
		y = 0 #start at 0 on y-axis
		angle = random.randint(200,269) #angles between 200-269 deg
		return Asteroid((x,y),angle)
		

def collides(info1, info2): #defining collision detection function
	(image1, rect1) = info1
	(image2, rect2) = info2
	mask1 = pygame.mask.from_surface(image1)
	mask2 = pygame.mask.from_surface(image2)
	dx = rect2.left - rect1.left
	dy = rect2.top - rect1.top
	return mask1.overlap(mask2, (dx,dy)) != None

class Spaceship(object): #Spaceship class
	def __init__(self):
		self.spaceship = pygame.transform.scale(pygame.image.load("spaceship.png"),(60,60))
		#author: Xevin
		#public domain: http://opengameart.org/content/simple-spaceship
		
		self.dying = False
		self.explosion = pygame.image.load("explosion.png")
		#author: Amir027
		#public domain: http://opengameart.org/content/star-explosion
		self.dead = False
		self.deathframecount = 0
	
	def mouse(self):
		self.mouse_x, self.mouse_y = pygame.mouse.get_pos()
		
	def draw(self,surface):
		'''if self.dying:
			rect = self.explosion.get_rect()
			rect.center = self.position
			screen.blit(self.explosion, rect)
			self.deathframecount += 1
			if self.deathframecount == 2 * fps:
				self.dead = True
			return'''
	
		self.spaceshipRect = self.spaceship.get_rect()
		screen.blit(self.spaceship,(self.mouse_x-26,self.mouse_y-26))
		
	def collision_info(self):
		spaceshipRect = self.spaceship.get_rect()
		return (self.spaceship, spaceshipRect)
		
class Asteroid(object): #Asteroid class
	def __init__(self, position, angle):
		asteroid = random.choice(["a1","a3","b1","b3","c1","c3","c4"])
		self.frames = []
		for i in range(0,16):
			frame = pygame.image.load("asteroids/%s%04d.png" % (asteroid, i))
			#author: phaelax
			#creative commons: http://opengameart.org/content/asteroids
			frame = pygame.transform.scale(frame, (160,120))
			self.frames.append(frame)
		
		self.frame = 0
		self.position = position
		self.angle = angle
		
	def move(self, speed):
		dx = speed * math.cos(math.radians(self.angle))
		dy = speed * math.sin(math.radians(self.angle))
		self.position = ( self.position[0] + dx, self.position[1] - dy )

	def on_screen(self, screen):
		rect = self.frames[self.frame//2].get_rect()
		rect.center = self.position
		return screen.get_rect().colliderect(rect)
		
	def draw(self, screen):
		rect = self.frames[self.frame//2].get_rect()
		rect.center = self.position
		screen.blit(self.frames[self.frame//2], rect)
		self.frame += 1
		if self.frame == 2*len(self.frames):
			self.frame = 0
			
	def collision_info(self):
		rect = self.frames[self.frame//2].get_rect()
		rect.center = self.position
		return (self.frames[self.frame//2], rect)
		

#screen size
pygame.init()
width = 800
height = 600
size = (width,height)
fps = 60

screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()

background = pygame.image.load("background.png")
#author: StumpyStrust
#public domain: http://opengameart.org/content/space-background-2

soundtrack = pygame.mixer.Sound("soundtrack.ogg")
soundtrack.set_volume(0.7)
soundtrack.play(-1)
#author: djsaryon
#creative commons: http://opengameart.org/content/battle-midi

explosionsound = pygame.mixer.Sound("explosion.wav")
explosionsound.set_volume(0.6)
#author: dklon
#creative commons: http://opengameart.org/content/atari-booms

spaceship = Spaceship()
asteroids = [ ]

while True:
	
	clock.tick(fps)
	
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()
			
	spaceship.mouse() #move spaceship with mouse in center of spaceship
	
	screen.blit(background, background.get_rect()) #draw background
	
	for asteroid in asteroids: #draw asteroids into empty list for loop
		asteroid.draw(screen)
		asteroid.move(5)
	asteroids = [ asteroid for asteroid in asteroids if asteroid.on_screen(screen) ]
	
	while len(asteroids) < 6: #have 6 asteroids on the playing screen at once
		asteroids.append(generate_asteroid(width,height))
	
	'''spaceshipinfo = spaceship.collision_info()
	
	for asteroid in asteroids:
		asteroidinfo = asteroid.collision_info()
		
		if collides(asteroidinfo, spaceshipinfo) and not spaceship.dying:
			explosionsound.play()
			spaceship.dying = True'''
	
	spaceship.draw(screen)
	pygame.display.flip()