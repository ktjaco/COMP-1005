from __future__ import division
import pygame

# initialize pygame
pygame.init()

# set up the screen
width = 640
height = 480
size = (width, height)
screen = pygame.display.set_mode(size)

red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
black = (0,0,0)
white = (255,255,255)

# specify how many frames per second should be drawn
fps = 40 # you may want to change this!

# set up the clock
clock = pygame.time.Clock()

while True:
	# draw a specified number of frames per second
	clock.tick(fps) 

	# check to see if the user wants to quit
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()

	# switch between different colour backgrounds
	screen.fill(red) # red background
	pygame.display.flip() # display screen
	pygame.time.wait(1000) # wait 1 second
	
	screen.fill(green) # green background
	pygame.display.flip() # display screen
	pygame.time.wait(1000) # wait 1 second
	
	screen.fill(blue) # blue background
	pygame.display.flip() # display screen
	pygame.time.wait(1000) # wait 1 second
	
	screen.fill(black) # black background
	pygame.display.flip() # display screen
	pygame.time.wait(1000) # wait 1 second
	
	screen.fill(white) # white background
	pygame.display.flip() # display screen
	pygame.time.wait(1000) # wait 1 second