from __future__ import division
import pygame
from time import strftime, gmtime

# initialize pygame
pygame.init()

# set up the screen
width = 640
height = 480
size = (width, height)
screen = pygame.display.set_mode(size)

# apply white background
white = (255,255,255)

# load image
img = pygame.image.load("ball.png")
imgrect = img.get_rect()

# coordinates for image
imgx = 0
imgy = 352

# pixel movement
pixmov = 35

movement = 'right'
img_angle = 0

# specify how many frames per second should be drawn
fps = 10

# set up the clock
clock = pygame.time.Clock()

while True:
	# draw a specified number of frames per second
	clock.tick(fps)
	
	# check to see if the user wants to quit
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()
			
	# clockwise movement
	# if movement is right, move x-axis of image 4 pixels
	# when imgx is greater than 512 pixels, move to the left
	if movement == 'right':
		imgx += pixmov
		img_angle = (img_angle - 90) % 360
		img = pygame.transform.rotate(img,img_angle)
		if imgx > 512:
			movement = 'left'
			print strftime("%S",gmtime())
	
	# counter clockwise movement
	# the movement is now left
	# now move the image negatives (left) by 4
	# when imgx is == 0 move it back into the right direction
	elif movement == 'left':
		imgx -= pixmov
		img_angle = (img_angle + 90) % 360
		img = pygame.transform.rotate(img,img_angle)
		if imgx == 0:
			movement = 'right'
			print strftime("%S",gmtime())
		
	# draw everything onto the screen
	screen.fill(white)
	screen.blit(img,(imgx,imgy))
	pygame.display.flip()