from __future__ import division
import pygame
import math
from time import strftime, gmtime

# initialize pygame
pygame.init()

# set up the screen
width = 640
height = 480
size = (width, height)
screen = pygame.display.set_mode(size)

img = pygame.image.load("ball.png")
#imgrect = img.get_rect()
img_angle = 0

#apply white background
white = (255,255,255)

# specify how many frames per second should be drawn
fps = 2

# set up the clock
clock = pygame.time.Clock()

while True:
	# draw a specified number of frames per second
	clock.tick(fps) 
	
	# check to see if the user wants to quit
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()
	
	# apply the angle to rotate counter clockwise
	img_angle = (img_angle + 90) % 360
	
	# draw everything onto the screen
	screen.fill(white)
	screen.blit(pygame.transform.rotate(img, img_angle),(width/2-64,height/2-64))
	#print strftime("%S",gmtime())
	pygame.display.flip()