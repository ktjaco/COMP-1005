from __future__ import division
import pygame
from time import strftime, gmtime

# initialize pygame
pygame.init()

# set up the screen
width = 640
height = 480
size = (width, height)
screen = pygame.display.set_mode(size)

# apply white background
white = (255,255,255)

# load image
img = pygame.image.load("ball.png")
imgrect = img.get_rect()

# x and y coordinates for the image
imgx = 0
imgy = 352

# pixel movement
pixmov = 4
movement = 'right'

# specify how many frames per second should be drawn
fps = 60

# set up the clock
clock = pygame.time.Clock()

while True:
	# draw a specified number of frames per second
	clock.tick(fps)
	
	# check to see if the user wants to quit
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()
	
	# if movement is right, move x-axis of image 4 pixels
	# when imgx is greater than 512 pixels, move to the left
	if movement == 'right':
		imgx += pixmov
		if imgx > 512:
			movement = 'left'
			print strftime("%S",gmtime()) # time stamp
	
	# the movement is now left
	# now move the image negatives (left) by 4
	# when imgx is == 0 move it back into the right direction
	elif movement == 'left':
		imgx -= pixmov
		if imgx == 0:
			movement = 'right'
			print strftime("%S",gmtime()) # time stamp
		
	# draw everything onto the screen
	screen.fill(white)
	screen.blit(img,(imgx,imgy))
	pygame.display.flip()