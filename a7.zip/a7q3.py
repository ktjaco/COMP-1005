from __future__ import division
import pygame

# initialize pygame
pygame.init()

# set up the screen
width = 640
height = 480
size = (width, height)
screen = pygame.display.set_mode(size)

#load image
img = pygame.image.load("ball.png")

#apply white for background
white = (255,255,255)

# specify how many frames per second should be drawn
fps = 20

# set up the clock
clock = pygame.time.Clock()

while True:
	# draw a specified number of frames per second
	clock.tick(fps) 

	# check to see if the user wants to quit
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()

	# draw everything onto the screen
	screen.fill(white)
	screen.blit(img,(width/2-64,height/2-64)) # center the image in the window
	pygame.display.flip()